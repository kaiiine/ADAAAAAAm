/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tpvente;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author 33608
 */
public class TPVente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
       
   

        // Créez un magasin avec une capacité de 100 équipements et 50 commandes
        Magasin magasin = new Magasin();
        magasin.depuisFichierCommandes();
        magasin.depuisFichierEquipements();
        
        LigneCommande[] panier = new LigneCommande[30];
        afficherMenu(magasin);
    }

    private static void afficherMenu(Magasin magasin) throws IOException {
        Scanner scanner = new Scanner(System.in);
        int choix;

        do {
            System.out.println("\nMenu:");
            System.out.println("1. Afficher toutes les commandes d'une collectivité");
            System.out.println("2. Afficher toutes les commandes devant être livrées après une date donnée");
            System.out.println("3. Ajouter un nouveau produit");
            System.out.println("4. Afficher les équipements disponibles");
            System.out.println("5. Ajouter une nouvelle commande");
            System.out.println("6. Quitter");

            System.out.print("Choix : ");
            choix = scanner.nextInt();
            scanner.nextLine();  // Pour consommer la nouvelle ligne restante après nextInt

            switch (choix) {
                case 1:
                    // Appeler la méthode pour afficher les commandes d'une liste de collectivités
                    System.out.println("Entrez les emails des collectivités séparés par des virgules : ");
                    String emailsCollectivitesString = scanner.nextLine();
                    List<String> emailsCollectivites = Arrays.asList(emailsCollectivitesString.split(","));
                    magasin.affichage(emailsCollectivites);
                    break;
                case 2:
                    // Appeler la méthode pour afficher les commandes devant être livrées après une date donnée
                    System.out.println("Entrez la date (YYYY-MM-DD) : ");
                    String dateString = scanner.nextLine();
                    magasin.affichage(LocalDate.parse(dateString));
                    break;
                case 3:
                    // Appeler la méthode pour ajouter une nouvelle commande
                    String answer3 = "";
                    System.out.println("Quel est le type de votre objet que vous souhaitez ajouter : \n");
                    System.out.println("Joueurs (1)");
                    System.out.println("Protection Joueurs (2)");
                    System.out.println("Terrain (3)\n");
                    while(!answer3.equals("1") && !answer3.equals("2") && !answer3.equals("3")){
                        answer3=scanner.nextLine();
                        System.out.print("Veuillez saisir les champs requis : \n");
                        System.out.print("Sport : ");
                        String sport=scanner.nextLine();
                        System.out.print("Désignation : ");
                        String designation = scanner.nextLine();
                        System.out.print("Prix : ");
                        double prix=Double.parseDouble(scanner.nextLine());
                        System.out.print("Nombres d'Exemplaires : ");
                        int nbrExemplaires = Integer.parseInt(scanner.nextLine());
                        switch(answer3){
                            case "1":
                                System.out.print("Taille : ");
                                String taille = scanner.nextLine();
                                System.out.print("Coloris : ");
                                String coloris = scanner.nextLine();
                                magasin.ajout(sport,designation,prix,nbrExemplaires,taille,coloris);
                                System.out.println("\n\nVotre article a bien été ajouté\n\n"); 
                                magasin.versFichierEquipement();
                                break;
                            case "2":
                                System.out.print("Taille : ");
                                String taille2 = scanner.nextLine();
                                System.out.print("Coloris : ");
                                String coloris2 = scanner.nextLine();
                                System.out.print("Niveau : ");
                                String niveau = scanner.nextLine();
                                magasin.ajout(sport,designation,prix,nbrExemplaires,taille2,coloris2,niveau);
                                System.out.println("\n\nVotre article a bien été ajouté\n\n");
                                magasin.versFichierEquipement();
                                break;
                            case "3":
                                System.out.print("Poids : ");
                                double poids = Double.parseDouble(scanner.nextLine());
                                System.out.println("--------------------------------------------------------------------------------------------------");
                                System.out.print("Hauteur : ");
                                double hauteur = Double.parseDouble(scanner.nextLine());
                                System.out.println("--------------------------------------------------------------------------------------------------");
                                System.out.print("Largeur : ");
                                double largeur = Double.parseDouble(scanner.nextLine());
                                System.out.println("--------------------------------------------------------------------------------------------------");
                                if(hauteur==0 && largeur==0){
                                    magasin.ajout(sport,designation,prix,nbrExemplaires,poids);
                                }else{
                                 magasin.ajout(sport,designation,prix,nbrExemplaires,poids,hauteur,largeur);   
                                }
                                System.out.println("\n\nVotre article a bien été ajouté\n\n");
                                magasin.versFichierEquipement();
                                break;
                        }
                    }
                    break;
                case 4:
                    // Appeler la méthode pour afficher les équipements disponibles
                    magasin.afficherEquipementsDisponibles();
                    break;
                case 5:
                    LigneCommande[] panier = new LigneCommande[30];
                    int cpt=0;
                    boolean continuer = true;
                    while(continuer){
                        String reponse = "";
                        LigneCommande article = magasin.choixEquip();
                        System.out.println("Souhaitez-vous continuer vos achats ? (O/N)");
                        while(!reponse.equalsIgnoreCase("O") &&!reponse.equalsIgnoreCase("N")){
                            reponse = scanner.nextLine();
                            if(reponse.equalsIgnoreCase("O")){
                                cpt+=1;
                                break;
                            }else if(reponse.equalsIgnoreCase("N")){
                                continuer=false;
                                break;
                            }else{
                                System.out.println("Erreur, veuillez saisir O pour oui ou N pour non");
                            }
                        }
                    }
                    
                    magasin.ajout(panier,cpt);
                    magasin.versFichierCommandes();
                    break;
                case 6:
                    System.out.println("Au revoir !");
                    break;
                default:
                    System.out.println("Choix invalide. Veuillez réessayer.");
                    break;
            }

        } while (choix != 5);
    }

}
    
