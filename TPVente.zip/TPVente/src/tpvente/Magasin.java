/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tpvente;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author anais
 */
public class Magasin {

    private String nommag = "Magasin A et A";
    public Commande[] tabcom = new Commande[30];
    private Equipement[] tabequip = new Equipement[30];
    private int nbEquipement = 0;
    private int nbCommande = 0;
    private List<Equipement> equipement;
    public List<LigneCommande>commande;
    static final String NOM_FICHIER_EQUIPEMENTS = "Equipement.txt" ; 
    static final String NOM_FICHIER_COMMANDES = "Commande.txt";
    
    
    private int compteurCommande =0;
    private int anneeActuelle=2023;
    
    private static int compteurJO = 0;
    private static int compteurPR = 0;
    private static int compteurTR = 0;

    public Magasin() {
        
    }

    public void Afficheinst() {
        System.out.println(nommag);

    }

    public String toString() {
        return "";
    }


    public void ajout(String sport, String designation, double prix, int nbExemplaire, double p, double h, double l) {
        Terrain a = new Terrain("TR000", sport, designation, prix, nbExemplaire, p, h, l);
        this.tabequip[this.nbEquipement] = a;
        this.nbEquipement += 1;
    }
    
    public void ajout(String sport, String designation, double prix, int nbExemplaire, double p) {
        Terrain a = new Terrain("TR000", sport, designation, prix, nbExemplaire, p);
        this.tabequip[this.nbEquipement] = a;
        this.nbEquipement += 1;
    }

    public void ajout(String sport, String designation, double prix, int nbExemplaire, String t, String c) {
        Joueurs a = new Joueurs("JO000", sport, designation, prix, nbExemplaire, t, c);
        this.tabequip[this.nbEquipement] = a;
        this.nbEquipement += 1;
    }

    public void ajout(String sport, String designation, double prix, int nbExemplaire,String t, String c, String niveau) {
        ProtectionJoueurs a = new ProtectionJoueurs("JO000", sport, designation, prix, nbExemplaire,t,c, niveau);
        this.tabequip[this.nbEquipement] = a;
        this.nbEquipement += 1;
    }

    public Equipement recherche(String reference) {
        for (int i = 0; i < tabequip.length; i++) {
            if (tabequip[i].getReference().equals(reference)) {
                return tabequip[i];
            }
        }
        return null;
    }

    public void Affichage(String type) {
        String ref;
        if (type.equals("Joueurs")) {
            ref = "JO";
        } else if (type.equals("Terrain")) {
            ref = "TR";
        } else {
            ref = "PR";
        }
        for (int i = 0; i < tabequip.length; i++) {
            if (tabequip[i].getReference().substring(0, 2).equals(ref)) {
                System.out.println(tabequip[i].toString());

            }
        }
    }

    public String getreference(String type) {
        String prefixe = "";
        switch (type) {
            case "TR":
                prefixe = "TR";
                return prefixe + String.format("%03d", ++compteurTR);// formater un entier en une chaîne de caractères,
            //en spécifiant que le nombre doit occuper au moins trois positions et être complété par des zéros à gauche si nécessaire
            case "JO":
                prefixe = "JO";
                return prefixe + String.format("%03d", ++compteurJO);
            case "PR":
                prefixe = "PR";
                return prefixe + String.format("%03d", ++compteurPR);
            default:
                return "Ce type ne fait pas partie des équpements";
        }
    }
       public LigneCommande choixEquip() {

        Scanner sc = new Scanner(System.in);      //Initialisation d'un scanner et des variables

        int cptnombre = 0;

        int cptdecale = 0;

        Equipement tab[];

        System.out.println("choisissez le type d’équipement");
        String reponsetype = sc.nextLine();

        System.out.println("choisissez le sport recherchés");
        String reponsesport = sc.nextLine();        //tabequip[i]

        for (int i = 0; i < nbEquipement; i++) {
            if (this.tabequip[i].getReference().substring(0, 2).equalsIgnoreCase(reponsetype.substring(0, 2)) && this.tabequip[i].getSport().equalsIgnoreCase(reponsesport)) {
                cptnombre += 1;

            }

        }

        tab = new Equipement[cptnombre];

        for (int i = 0; i < nbEquipement; i++) {
            if (tabequip[i].getReference().substring(0, 2).equalsIgnoreCase(reponsetype.substring(0, 2)) && tabequip[i].getSport().equalsIgnoreCase(reponsesport)) {

                tab[cptdecale] = tabequip[i];

                cptdecale++;

                System.out.println(tabequip[i].toString());

            }
        }
// Demander au client de choisir une référence et le nombre d'exemplaires pour chaque équipement
            LigneCommande lignesCommande;


                
                System.out.println("Choisissez la référence de l'équipement : ");
                String referenceChoisie = sc.nextLine();

                System.out.println("Choisissez le nombre d'exemplaires de l'équipement : ");
                int nombreExemplairesChoisi = sc.nextInt();
                sc.nextLine();  // Pour consommer la nouvelle ligne restante après nextInt

                Equipement ekip = recherche(referenceChoisie);  //Récupère l'objet choisie par l'utilisateur
                
                // Créer la ligne de commande correspondante
                lignesCommande= new LigneCommande(referenceChoisie, nombreExemplairesChoisi, ekip.getPrix());
                
                
                ekip.majDispo(-nombreExemplairesChoisi);    // Modifie la quantité du produit


                return lignesCommande;
        
    }
    public void afficherEquipementsDisponibles() {
    System.out.println("Équipements disponibles : ");
    for (Equipement equipement : tabequip) {
        if (equipement != null) {
            System.out.println(equipement);
        }
    }
}
    public double calculerMontantTotal(LigneCommande[] tab, int nombreArticle) {
    double montantTotal = 0;

    for (int i=0;i<nombreArticle;i++) {
        if(tab[i] !=null){
            Equipement ekip = recherche(tab[i].getReference());
            montantTotal += ekip.getPrix() * tab[i].getNombreExemplaires();
        }
    }

    return montantTotal;
}
    private int genererNumeroCommande() {
        int annee = LocalDate.now().getYear();
        if(annee!=this.anneeActuelle){  //Si on change d'année, le compteur doit se rénitialiser à zéro
            compteurCommande=0;
            anneeActuelle=annee;
        }
        int numero = compteurCommande;
        compteurCommande+=1;
        return Integer.parseInt(String.format("%d%04d", this.anneeActuelle, numero));
    }



 public void ajout(LigneCommande[] tabCommande,int nombreArticle) {
    
    Scanner sc = new Scanner(System.in);

    // Demander l'email de la collectivité
    System.out.println("Entrez l'email de la collectivité : ");
    String emailCollectivite = sc.nextLine();

    // Obtenir la date d'émission et la date de livraison prévue
    LocalDate dateEmission = LocalDate.now();
    LocalDate dateLivraisonPrevue; 
    int joursLivraison = 3;

    for(int i=0;i<nbCommande;i++){  //Récupère l'article qui prend le plus de jours à se faire livrer
        if(tabCommande[i]!=null){
            Equipement ekip = recherche(tabCommande[i].getReference());
            int delaiEkip = ekip.calculDelai(tabCommande[i].getNombreExemplaires());
            if(delaiEkip > joursLivraison){
                joursLivraison=delaiEkip;
            }
        }
    }
    
    dateLivraisonPrevue = dateEmission.plusDays(joursLivraison);
    // Créer la commande
        Commande nouvelleCommande = new Commande( genererNumeroCommande(), emailCollectivite, dateEmission, dateLivraisonPrevue, calculerMontantTotal(tabCommande,nombreArticle), tabCommande);

        

    // Ajouter la commande au tableau de commandes du magasin
    tabcom[nbCommande] = nouvelleCommande;
    nbCommande++;

    // Afficher les détails de la commande
    System.out.println("Commande enregistrée avec succès : ");
    System.out.println(nouvelleCommande);

    System.out.println("Montant total de la commande : " + calculerMontantTotal(tabCommande,nombreArticle));
    System.out.println("Arrivée estimée le : " + dateLivraisonPrevue);
}
 
 
 
     public void affichage(List<String> emailsCollectivites) {
        System.out.println("Commandes pour les collectivités : " + emailsCollectivites);

        for (Commande commande : tabcom) {
            if (commande != null && emailsCollectivites.contains(commande.getemailCollectivite())) {
                System.out.println(commande);
            }
        }
    }
     public void affichage(LocalDate dateLimite) {
        System.out.println("Commandes devant être livrées après " + dateLimite + ":");

        for (Commande commande : tabcom) {
            if (commande.getDateLivraisonPrevue().isAfter(dateLimite)) {
                System.out.println(commande);
            }
        }
    }
public void versFichierEquipement() throws IOException {

        FileWriter fich = new FileWriter(NOM_FICHIER_EQUIPEMENTS);
        for (int i = 0; i < this.nbEquipement; i++) {     // Boucle for pour parcourir le tableau equipement

            String chaine = this.tabequip[i].versFichier() + System.lineSeparator();     //Créer une chaîne de caracrère en y inscrivant les différents attributs des équipements

            fich.write(chaine);     //Saisi dans le fichier texte les différents attributs des équipements

        }

        fich.close();   //Ferme le fichier

    }
    
    
public void depuisFichierEquipements() throws FileNotFoundException, IOException {  //IOException : Gère les problèmes de fichiers introuvable, autorisations sinsuffisantes etc...

        FileReader fich = new FileReader(NOM_FICHIER_EQUIPEMENTS); // Crée un objet FileWriter pour écrire dans le fichier texte Equipements et gère les exceptions d'entrée/sortie.

        BufferedReader br = new BufferedReader(fich);   //Un BufferedReader offre des méthodes pour lire des données à partir d'un flux de caractères (comme un fichier)

        String ref = br.readLine(); //Le curseur commence automatiquement à la ligne 1 du fichier texte, afin de récupère la référence, puis place le curseur à la ligne 2

       

        // **** REMARQUE : Les références sont situés sur les lignes impaires (1,3,5,...,2n+1), et les autres atttributs sur les lignes paires (2,4,6,...,2n). Voir un exemple de fichier texte ****

       

        while (ref != null) {  

            String ligne = br.readLine();   //Le curseur, situé à la ligne 2n, va récupérer les valeurs de cette ligne en les enregistrant dans la chaine de caractère "ligne", puis place le curseur à la ligne (2n+1)

            String[] tab = ligne.split(" : ");  //Sépare la chaine de caractère lorsqu'il y a la valeur " : " et range chacunes des parties (attributs) dans un case du tableau

            Equipement equip;   //On initialise un objet equipement ansi que les attributs de la classe Equipements communs à tous les objets présents dans les 4 premières cases du tableau tab

            String sport = tab[0];

            String nom = tab[1];

            double prix = Double.parseDouble(tab[2]);

            int nbrExemplaires = Integer.valueOf(tab[3]);

            if (ref.startsWith("JO")) {     //On vérifie quel type d'equipement c'est en fonction de sa référence afin de récupérer les derniers attributs pour créer cet equipement

                String taille = tab[4];

                String coloris = tab[5];
                
                equip = new Joueurs(ref, sport, nom, prix, nbrExemplaires, taille, coloris);

            } else if (ref.startsWith("PR")) {

                String taille = tab[4];

                String coloris = tab[5];

                String niveau = tab[6];

                equip = new ProtectionJoueurs(ref, sport, nom, prix, nbrExemplaires, taille, coloris, niveau);

            } else {

                double poids = Double.parseDouble(tab[4]);

                double hauteur = Double.parseDouble(tab[5]);

                double largeur = Double.parseDouble(tab[6]);

                equip = new Terrain(ref, sport, nom, prix, nbrExemplaires, poids, hauteur, largeur);

            }

            this.tabequip[nbEquipement]=equip;    //On ajoute l'equipement dans le tableau equipements

            //sortEquipement();   //Tri du taleau

            this.nbEquipement += 1;    // On ajoute (+1) au compteur d'equipements

            ref = br.readLine();    // Le curseur situé à la ligne (2n+1) va récupérer la référence de la ligne puis il va se placer à la ligne 2n

 

        }

        fich.close();   //A la fin on ferme le fichier

    }

    public void versFichierCommandes() throws IOException {

        FileWriter fich = new FileWriter(NOM_FICHIER_COMMANDES); 

 
        for (int i = 0; i < this.nbCommande; i++) {     // Boucle for pour parcourir le tableau equipements

            String chaine = this.tabcom[i].versFichier() + System.lineSeparator()+this.tabcom[i].getNbrCommandes()+System.lineSeparator();     //Créer une chaîne de caracrère en y inscrivant les différents attributs des équipements

            for(int j=0;j<this.tabcom[i].getNbrCommandes();j++){
                if(this.tabcom[i].getNbrLigneCommande(j)!=null){
                    chaine+=this.tabcom[i].getNbrLigneCommande(j).versFichier();
                }
            }

            fich.write(chaine);     //Saisi dans le fichier texte les différents attributs des équipements

        }

 

        fich.close();   //Ferme le fichier

 

    }

    

     public void depuisFichierCommandes() throws FileNotFoundException, IOException {  //IOException : Gère les problèmes de fichiers introuvable, autorisations sinsuffisantes etc...

        FileReader fich = new FileReader(NOM_FICHIER_COMMANDES); // Crée un objet FileWriter pour écrire dans le fichier texte Equipements et gère les exceptions d'entrée/sortie.

        BufferedReader br = new BufferedReader(fich);   //Un BufferedReader offre des méthodes pour lire des données à partir d'un flux de caractères (comme un fichier)

        String numero = br.readLine(); //Le curseur commence automatiquement à la ligne 1 du fichier texte, afin de récupère le numéro de la commande, puis place le curseur à la ligne 2

 

       

        while (numero != null) {  

            String ligne = br.readLine();   //Le curseur, situé à la ligne 2n, va récupérer les valeurs de cette ligne en les enregistrant dans la chaine de caractère "ligne", puis place le curseur à la ligne (2n+1)

            String[] tab = ligne.split(" : ");  //Sépare la chaine de caractère lorsqu'il y a la valeur " : " et range chacunes des parties (attributs) dans un case du tableau


            String email = tab[0];

            LocalDate dateEmission = LocalDate.parse(tab[1]);

            LocalDate dateLivraison = LocalDate.parse(tab[2]);

            Double prixTot = Double.parseDouble(tab[3]);

            int nbrArticles = Integer.parseInt(br.readLine());  // Lit la ligne comportant le nombre d'articles de la commande
            LigneCommande[] listeCommandes=new LigneCommande[nbrArticles];   //On initialise un tableau dynamique (pour chaque commande) de LigneCommande afin de renseigner tous les articles d'une commande dedans
            int cpt=0;
            for(int i=0;i<nbrArticles;i++){     // Boucle afin de créer et d'ajouter les objets LigneCommande

                ligne = br.readLine();  // Récupère les valeurs de l'article

                tab = ligne.split(" : ");   //Sépare la chaine de caractère lorsqu'il y a la valeur " : " et range chacunes des parties (attributs) dans un case du tableau

                String ref=tab[0];  // Récupération des attributs dans des variables à partir du tableau

                int nbrExemplaires = Integer.parseInt(tab[1]);

                double prixUnit = Double.parseDouble(tab[2]);

                LigneCommande article = new LigneCommande(ref,nbrExemplaires,prixUnit); // Création d'un objet LigneCommande

                listeCommandes[cpt]=article;    // Rajout de l'objet au sein du tableau dynamique listeCommandes
                cpt+=1;
            }

            Commande commande = new Commande(Integer.parseInt(numero),email,dateEmission,dateLivraison,prixTot,listeCommandes);   // Création de l'objet Commande
            
            this.tabcom[this.nbCommande] = commande;   // On ajoute l'objet commande dans le tableau commandes

            this.nbCommande+=1;   // On ajoute (+1) au compteur de commandes


           

            numero = br.readLine();    // Le curseur situé à la ligne (2n+1) va récupérer la référence de la ligne puis il va se placer à la ligne 2n

 

        }

        fich.close();   //A la fin on ferme le fichier

    }
     
}
