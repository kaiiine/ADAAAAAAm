/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tpvente;

import java.util.Arrays;

public abstract class Equipement {

    // Attributs
    private String reference;
    private String sport;
    private String designation;
    private double prix;
    private int nombreExemplaires;

    public Equipement(String reference, String sport, String designation, double prix, int nombreExemplaires) {
        this.reference = reference;
        this.sport = sport;
        this.designation = designation;
        this.prix = prix;
        this.nombreExemplaires = nombreExemplaires;
    }

    public Boolean placeApres(Equipement objet) {
        Boolean trie = false;
        for (int i = 0; i < 5; i++) {
            if (this.reference.charAt(i) > objet.reference.charAt(i)) {
                trie = true;
                break;
            }
        }
        return trie;
    }

    public String toString() {   // Création de la méthode toString dans la classe mère. Cela permet de faire  marcher le super.toString() dans les classes filles (Joueurs, Terrain et ProtectionJoueurs), car le super.toString() appel d'abord cette méthode
        return "Reference : " + this.reference + ", Sport : " + this.sport + ", Designation : " + this.designation + ", Prix : " + this.prix + ", Nombre d'exemplaires : " + this.nombreExemplaires;
    }

    /* public void placeApres(Equipement tab1[]) {
        Arrays.sort(tab1);
        System.out.println(Arrays.toString(tab1));
    }*/
    public String getReference() {
        return this.reference;
    }

    public String getSport() {
        return this.sport;

    }

    public double getPrix() {
        return this.prix;
    }

    public int getNombreExemplaires() {
        return this.nombreExemplaires;
    }

    public void setNombreExemplaires(int nouveauStock) {
        this.nombreExemplaires = nouveauStock;
    }

    public abstract double getPoids(); // Création d'une méthode abstraite pour récupérer le poids d'un Terrain sans y avoir d'erreur

    public abstract double getHauteur();    // Similaire pour le poids

    public abstract double getLargeur();    // Similaire pour le poids

    public String versFichier() {

        return getReference() + System.lineSeparator() + sport + " : " + designation + " : " + prix + " : " + nombreExemplaires;
        /* Retourne une chaine de caractère contenant la référence, un retour à la ligne,

                                                                                                                        puis les attributs de la classe mère tous séparés par " : "  */

    }

    public void majDispo(int qtt) {
        this.nombreExemplaires += qtt;
    }

    public boolean verifDispo(int qtt) {
        if (qtt < this.nombreExemplaires) {
            return true;
        } else {
            return false;
        }
    }

    public int calculDelai(int qtt) {
        int delai = 3;
        if (this.getPoids() * qtt >= 100) {
            delai = 5;
        }
        if (!this.verifDispo(qtt)) {
            delai += 30;
        }
        return delai;
    }

}
