/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tpvente;
import java.util.Arrays;


/**
 *
 * @author 33608
 */
public class LigneCommande {
    private String referenceEquipement;
    private int nombreExemplaires;
    private double prixUnitaire;

    public LigneCommande(String referenceEquipement, int nombreExemplaires, double prixUnitaire) {
        this.referenceEquipement = referenceEquipement;
        this.nombreExemplaires = nombreExemplaires;
        this.prixUnitaire = prixUnitaire;
    }
        public String toString() {
        return "Ligne de Commande [Référence de l'équipement=" + referenceEquipement + ", Nombre d'exemplaires=" + nombreExemplaires + ", Prix Unitaire=" + prixUnitaire + "]";
    }
  public String getReference() {
        return referenceEquipement;
    }
    public double getPrix() {
        return prixUnitaire;
    }
    public int getNombreExemplaires() {
        return nombreExemplaires;
}       
    public String versFichier(){
        return this.referenceEquipement + " : " + this.nombreExemplaires + " : " + this.prixUnitaire + System.lineSeparator();
    }
}
