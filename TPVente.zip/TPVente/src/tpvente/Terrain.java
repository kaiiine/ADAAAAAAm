/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tpvente;

/**
 *
 * @author 33608
 */
public class Terrain extends Equipement {
    private double poids;
    private double hauteur;
    private double largeur;

    public Terrain(String reference, String sport, String designation, double prix, int nombreExemplaires, double poids, double hauteur, double largeur) {
        super(reference, sport, designation, prix, nombreExemplaires);
        this.poids = poids;
        this.hauteur = hauteur;
        this.largeur = largeur;
    }
    
    public Terrain(String reference, String sport, String designation, double prix, int nombreExemplaires, double poids) {
        super(reference, sport, designation, prix, nombreExemplaires);
        this.poids = poids;
    }
   
    // Méthode toString spécifique pour la classe Terrain
    public String toString() {
        return super.toString() + " Terrain [Poids=" + poids + ", Hauteur=" + hauteur + ", Largeur=" + largeur + "]";
    }
    
    public String versFichier(){            // J'ai changé les attributs ici qui étaient mauvais (il y avait this.coloris et this.taille

            return super.versFichier() + " : " + this.poids + " : " + this.hauteur + " : " + this.largeur;    /* Retourne une chaine de caractère contenant la référence, un retour à la ligne,

                                                                                           les attributs de la classe mère + ceux de la classe Joueurs, tous séparés par " : "  */

        }
    
    @Override
    public double getPoids(){
        return this.poids;
    }
    
    @Override
    public double getHauteur(){
        return this.hauteur;
    }
    
    @Override
    public double getLargeur(){
        return this.largeur;
    }
}
    