/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tpvente;
import java.util.Arrays;


public class Joueurs extends Equipement {
    private String taille;
    private String coloris;

    public Joueurs(String reference, String sport, String designation, double prix, int nombreExemplaires, String taille, String coloris) {
        super(reference, sport, designation, prix, nombreExemplaires);
        this.taille = taille;
        this.coloris = coloris;
    }
    

    // Méthode toString spécifique pour la classe Joueurs
    public String toString() {
        return super.toString() + " Joueurs [Taille=" + taille + ", Coloris=" + coloris + "]";
    }
    public String versFichier(){

            return super.versFichier() + " : " + this.taille + " : " + this.coloris;    /* Retourne une chaine de caractère contenant la référence, un retour à la ligne,

                                                                                           les attributs de la classe mère + ceux de la classe Joueurs, tous séparés par " : "  */

        }
    
    @Override
    public double getPoids(){   // Obliger d'initialiser 
        return 0;
    }
    @Override
    public double getHauteur(){
        return 0;
    }
    
    @Override
    public double getLargeur(){
        return 0;
    }
}