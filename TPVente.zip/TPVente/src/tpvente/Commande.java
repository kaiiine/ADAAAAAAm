/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tpvente;

/**
 *
 * @author 33608
 */
import java.util.concurrent.atomic.AtomicInteger;
import java.time.LocalDate;
public class Commande {

    private int numeroCommande;
    private String emailCollectivite;
    private LocalDate dateEmission;
    private LocalDate dateLivraisonPrevue;
    private double totalCommande;
    private LigneCommande[] lignesCommande = new LigneCommande[30];
    private int compteurArticle = 0;

    public Commande(int numeroCommande, String emailCollectivite, LocalDate dateEmission, LocalDate dateLivraisonPrevue, double totalCommande, LigneCommande[] lignesCommande) {
        this.numeroCommande = numeroCommande;
        this.emailCollectivite = emailCollectivite;
        this.dateEmission = dateEmission;
        this.dateLivraisonPrevue = dateLivraisonPrevue;
        this.totalCommande = totalCommande;
        for(int i=0;i<lignesCommande.length;i++){
            this.lignesCommande[i] = lignesCommande[i];
            if(this.lignesCommande[i]!=null){
                compteurArticle+=1;
            }
        }
        
        
    }

    public String toString() {


        return "Commande [Numéro de Commande=" + numeroCommande + ", Email de la Collectivité=" + emailCollectivite + "\n"
                + "Date d'Émission=" + dateEmission + ", Date de Livraison Prévue=" + dateLivraisonPrevue + "\n"
                + "Total de la Commande=" + totalCommande + "\n";
    }

    public LigneCommande getNbrLigneCommande(int i) {
        return this.lignesCommande[i];
    }

    public int getNbrCommandes() {
        return this.compteurArticle;
    }

        public int getNumeroCommande() {
            return this.numeroCommande;
        }

    public String versFichier() {
        return this.numeroCommande + System.lineSeparator() + this.emailCollectivite + " : " + this.dateEmission + " : " + this.dateLivraisonPrevue + " : " + this.totalCommande;
    }

        public boolean placeApres(Commande autreCommande) {
            if (this.emailCollectivite.compareTo(autreCommande.emailCollectivite) > 0) {
                return true;
            } else if (this.emailCollectivite.compareTo(autreCommande.emailCollectivite) == 0 && this.numeroCommande > autreCommande.numeroCommande) {
                return true;
            } else {
                return false;
            }
        }

        public double calculerMontantTotal() {
            double montantTotal = 0;

            for (LigneCommande ligneCommande : lignesCommande) {
                montantTotal += ligneCommande.getPrix() * ligneCommande.getNombreExemplaires();
            }

            return montantTotal;
        }



    public String getemailCollectivite() {
        return this.emailCollectivite;
    }

    public LocalDate getDateLivraisonPrevue() {
        return this.dateLivraisonPrevue;
    }

}
