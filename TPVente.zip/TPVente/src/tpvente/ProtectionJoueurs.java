/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tpvente;

/**
 *
 * @author 33608
 */
public class ProtectionJoueurs extends Joueurs {
    private String niveauPratique;

    public ProtectionJoueurs(String reference, String sport, String designation, double prix, int nombreExemplaires, String taille, String coloris, String niveauPratique) {
        super(reference, sport, designation, prix, nombreExemplaires, taille, coloris);
        this.niveauPratique = niveauPratique;
    }

    // Méthode toString spécifique pour la classe ProtectionJoueurs
    public String toString() {
        return super.toString() + " ProtectionJoueurs [Niveau de Pratique=" + niveauPratique + "]";
    }
    
    public String versFichier(){    // J'ai changé les attributs ici qui étaient mauvais (il y avait this.coloris et this.taille

            return super.versFichier() + " : " + this.niveauPratique;    /* Retourne une chaine de caractère contenant la référence, un retour à la ligne,

                                                                                           les attributs de la classe mère + ceux de la classe Joueurs, tous séparés par " : "  */

        }
}